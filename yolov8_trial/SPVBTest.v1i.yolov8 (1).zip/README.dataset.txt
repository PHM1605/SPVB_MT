# SPVBTest > 2023-06-26 10:55am
https://universe.roboflow.com/hoang-minh-pham-6qdrp/spvbtest

Provided by a Roboflow user
License: CC BY 4.0

